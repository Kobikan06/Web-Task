import React from 'react';

const MainContent = () => {
  return (
    <div className="body-section">
    
    <div className="heading-section">
      <h1>
        The Future of Manufacturing <br/> with Latest Technology
      </h1>
      <p>Expert tech to elevate your manufacturing. Let's take your business further.</p>
      <div className="buttons">
        <button className="btn-primary">Get Started</button>
        <button className="btn-secondary">Try Demo</button>
      </div>
    </div>

    <p className="mt-4 text-yellow-500" align="center" >⭐⭐⭐⭐⭐ 5.0 <br/>from 80+ reviews.</p>

    <div className="stats-section">
      <div className="image-card">
        <img
          src="Screenshot_31-1-2025_144137_.jpeg"
           alt="Manufacturing Pipes"
        />
      </div>
      <div className="stats-card stats-dark">
        <h3>100+</h3>
        <p>Our Esteemed Clients and Partners</p>
      </div>
      <div className="stats-card stats-light">
        <h3>1951+</h3>
        <p>Total Projects</p>
        <p className="growth-text">Increase of 126 this month</p>
      </div>
      <div className="stats-card stats-green">
        <h3>6+</h3>
        <p>Years of Dedicated Service</p>
      </div>
      <div className="stats-card stats-dark">
        <h3>Achieve Optimal Efficiency and Boost Productivity</h3>
      </div>
    </div>
  </div>
  );
};


export default MainContent;
