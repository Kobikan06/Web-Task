import React from 'react';
import '../styles/colors.css';

const Header = () => {
  return (
    <header className="header">
      
      <nav className="navbar">
        
        <div className="logo">
          <img
            src="282599.webp" 
            className="logo-image"
            alt="Logo"
          />
          <span className="logo-text">Prodmast</span>
        </div>

        
        <ul className="nav-links">
          <li className="nav-item">
            <a href="#home" className="nav-link">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a href="#about" className="nav-link">
              About
            </a>
          </li>
          <li className="nav-item">
            <a href="#services" className="nav-link">
              Services
            </a>
          </li>
          <li className="nav-item">
            <a href="#contact" className="nav-link">
              Contact
            </a>
          </li>
        </ul>

        
        <button className="button">Sign Up</button>
      </nav>
    </header>
  );
};

export default Header;
