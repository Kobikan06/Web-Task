import React from "react";
import '../styles/colors.css';

const Footer = () => {
  const services = [
    {
      
      title: "Production and Assembly",
      description: "Details on production processes, assembly, capacity, and product types.",
    },
    {
      
      title: "Custom Manufacturing",
      description: "Custom product creation with design and customization options.",
    },
    {
      
      title: "Quality Control",
      description: "Procedures and systems in place to ensure high product quality.",
    },
    {
      
      title: "Technology and Innovation",
      description: "Details on the latest manufacturing technologies and ongoing innovations.",
    },
    {
      
      title: "Packaging and Logistics",
      description: "Packaging and logistics for shipping to customers and distributors.",
    },
    {
      
      title: "Consulting Market Research",
      description: "Services to help companies understand market needs and provide strategic advice.",
    },
  ];

  return (
    <div className="footer">
      <div className="footer-header">
        <h2>Efficient and Integrated <br/>  Manufacturing Services</h2>
        <p>Simplify operations with our efficient, quality-focused services.</p>
      </div>
      <div className="footer-services">
        {services.map((service, index) => (
          <div key={index} className="footer-card">
            <div className="footer-card-top">
              <div className="footer-icon">{service.icon}</div>
              <div className="footer-arrow">
                
              </div>
            </div>
            <h3 className="footer-title">{service.title}</h3>
            <p className="footer-description">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Footer;
